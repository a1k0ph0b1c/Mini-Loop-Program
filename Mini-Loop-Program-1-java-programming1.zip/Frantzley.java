// Frantzley Simeon
// January 24, 2023
// In this program, we are using a while loop to repeatedly read numbers from the user until either 10 numbers have been read or the user enters 0.

import java.util.Scanner;

// The Scanner class is used to read input from the user.
public class IntegerSums {
  public static void main(String[] args) {
    int count = 0;
    // The count variable is used to keep track of how many numbers have been read
    // so far, and the sum variable is used to keep track of the sum of the numbers.
    int sum = 0;
    Scanner scanner = new Scanner(System.in);

    while (count < 10) {
      System.out.print("Enter a number: ");
      int num = scanner.nextInt();

      if (num == 0) {
        break;
        // The break statement is used to exit the loop when the user enters 0. The
        // final sum is printed out after the loop exits.
      }

      sum += num;
      count++;
    }

    System.out.println("Sum of numbers entered: " + sum);
  }
}